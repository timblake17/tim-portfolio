<section class="hero-banner">
  <?php echo the_post_thumbnail(); ?>
  <div class="content">
    <?php echo the_content(); ?>
    <a href="#">
    <button>Button</button>
    </a>
  </div>
</section>
