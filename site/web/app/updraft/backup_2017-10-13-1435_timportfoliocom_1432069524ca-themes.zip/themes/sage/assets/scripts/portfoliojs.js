(function($) {
	//your code here
})(jQuery);
