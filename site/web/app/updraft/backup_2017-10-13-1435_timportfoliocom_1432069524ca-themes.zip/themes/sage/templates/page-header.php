<?php use Roots\Sage\Titles; ?>

<div class="">
  <h1><?= Titles\title(); ?></h1>
</div>
